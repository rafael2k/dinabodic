#!/bin/sh
JAVA_PATH=/usr/bin
PROJECT_PATH=.

cd $PROJECT_PATH
$JAVA_PATH/java -Dfile.encoding=UTF-8 -jar *.jar



